package com.example.mvvm.model.local

object Constant {
    const val DATABASE_NAME = "NEWS DB"
    const val DATABASE_VERSION = 1
}