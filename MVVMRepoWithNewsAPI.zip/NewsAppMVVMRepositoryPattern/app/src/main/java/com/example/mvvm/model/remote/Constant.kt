package com.example.mvvm.model.remote

object Constant {
    const val BASE_URL = "https://api.currentsapi.services/v1/"
    const val AUTH_TOKEN = "ehTUs_L7VNOevxSsW301L3Y6KhOmJ573Grs-VKu--uPjKPZF"
}